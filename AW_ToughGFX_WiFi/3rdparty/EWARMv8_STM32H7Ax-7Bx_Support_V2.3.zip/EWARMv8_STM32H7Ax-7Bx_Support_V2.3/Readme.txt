/******************** (C) COPYRIGHT 2020 STMicroelectronics ****************************************
* File Name          : readme.txt
* Author             : STMicroelectronics
* Version            : V2.3
* Date               : 11/03/2020
* Description        : This file describes how to add STM32H7A/B devices  support for EWARM 
****************************************************************************************************

These packages contains the needed files to be installed in order to support STM32H7A/B 
devices by EWARM8 and laters.

1. If you have already installed a Tiny shark patch before, you can remove it by running 
Uninstall_Patch.bat (run as administrator).

2.Running the "EWARMv8_STM32H7Ax-7Bx_Support_V2.3.exe" will add the following:
 - RPNs without SMPS:STM32H7A/B3xx  
 - RPNs with SMPS:STM32H7A/B3xx-Q 
 - Adding support for new RPNs value line: STM32HB0xx
 - STM32H7B3I-EVAL dedicated connection with OSPI external loader support (revB)
 - STM32H7B3I-EVAL dedicated connection with FMC NOR external loader support 
 - STM32H7B3I_DISCO dedicated connection with OSPI external loader support
 - STM32H7B0x_DISCO dedicated connection with OSPI external loader support
 - STM32H7B0x_EVAL dedicated connection with OSPI external loader support
 - Automatic STM32H7A/B flash algorithm selection
 - SVD file for STM32H7A/B 

PS: when using external loader on EWARM, please unselect the verify from the debug menu

How to use:
==========
* Before installing the files mentioned above, you need to have EWARM v8.xx 
or later installed. 
You can download EWARM from IAR web site @ www.iar.com
 
* Run "EWARMv8_STM32H7Ax-7Bx_Support_V2.3.exe" as administrator on EWARM install directory.
Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \", 


******************* (C) COPYRIGHT 2020 STMicroelectronics *****END OF FILE***************





	



